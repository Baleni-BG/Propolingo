package com.propolingo.propolinfo.security;

import com.propolingo.propolinfo.model.Models;
import com.propolingo.propolinfo.repository.User;

// Class is not really secure ... Just a security demonstration
public class SecurityContext {

    private User potentialUser;
    private User securityContextUser;

    public void setLoginDetails(String username , String password){
        this.potentialUser =new User();
        this.potentialUser.setPassword(password);
        this.potentialUser.setUsername(username);
    }

    public boolean authenticate(User user){
        User authUser;
        if (user.getPassword().isEmpty() || user.getUsername().isEmpty())
           return false;
        authUser=Models.getInstance().getPropolingoDatabase().fetchByUsername(user.getUsername());
        if (authUser==null)
            return false; // User does not exist

        potentialUser.setId(authUser.getId());
        potentialUser.setEmail(authUser.getEmail());
        potentialUser.setName(authUser.getName());
        potentialUser.setSurname(authUser.getSurname());
        return user.getPassword().trim().equals(authUser.getPassword());
    }

    public User getSecurityContextUser(){
        if (authenticate(potentialUser))
            return (securityContextUser=potentialUser);
        return null;
    }

}
