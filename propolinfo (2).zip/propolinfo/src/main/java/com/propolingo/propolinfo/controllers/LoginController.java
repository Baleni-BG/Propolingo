package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.LoginModel;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import javafx.scene.layout.AnchorPane;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController  implements Initializable {

    @FXML
    public AnchorPane details2;

    @FXML
    public AnchorPane invalid_log_in_details_anchorpane;
    @FXML
    public AnchorPane layer_1;
    @FXML
    public AnchorPane layer_2;
    @FXML
    public PasswordField password;
    @FXML
    public Button sign_in_layer2;
    @FXML
    public Button sign_up_button_layer2;
    @FXML
    public TextField sign_up_email_field;
    @FXML
    public AnchorPane sign_up_form;
    @FXML
    public TextField sign_up_name_field;
    @FXML
    public PasswordField sign_up_password_field;
    @FXML
    public TextField sign_up_surname_field;
    @FXML
    public TextField sign_up_username_field;
    @FXML
    public Button signin_button;
    @FXML
    public TextField username;

    @FXML
    public Button signup_button_1;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        LoginModel loginModel = new LoginModel();
        assign(loginModel);

        signin_button.setOnAction(e->{
            try {
                loginModel.getApp();

            } catch (Exception ex) {
                System.err.println("Error occurred on getAp() , login Controller");
            }

        });



        signup_button_1.setOnAction(e -> {loginModel.animateSignUp();

        System.out.println("Detected a press");
        });

        sign_in_layer2.setOnAction(e->loginModel.animateSignIn());

        sign_up_button_layer2.setOnAction(e ->{

            System.out.println("Signed Up Successfully : "+ loginModel.signUp());

        });


    }


    public void assign(LoginModel loginModel){
        //Layer-1
        loginModel.setUsername(username);
        loginModel.setPassword(password);
        loginModel.setSignIn_button(signin_button);

        // Layer-2-Sign UP
        loginModel.setSign_up_username_field(sign_up_username_field);
        loginModel.setSign_up_password_field(sign_up_password_field);
        loginModel.setSign_up_email_field(sign_up_email_field);
        loginModel.setSign_up_name_field(sign_up_name_field);
        loginModel.setSign_up_surname_field(sign_up_surname_field);
        loginModel.setSign_up_button_layer2(sign_up_button_layer2);
        loginModel.setSign_up_form(sign_up_form);
        loginModel.setDetails2(details2);

        // Layer-2

        loginModel.setLayer_11(layer_2);

        // Layer -2 SIGN IN
        loginModel.setSign_in_layer2(sign_in_layer2); //Button


        // Layer-1
        loginModel.setLayer_1(layer_1);

        loginModel.setInvalid_log_in_details_anchorpane(invalid_log_in_details_anchorpane);

    }


}
