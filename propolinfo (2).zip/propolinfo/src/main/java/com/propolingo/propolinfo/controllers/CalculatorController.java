package com.propolingo.propolinfo.controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.web.WebView;
import javafx.scene.web.WebEngine;

import java.net.URL;
import java.util.ResourceBundle;

public class CalculatorController implements Initializable {

    private static final String CALCULATOR_URL = "https://propositional-calculator.com/";

    @FXML
    private WebView webview;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        WebEngine webEngine = webview.getEngine();
        webEngine.load(CALCULATOR_URL);
    }
}
