package com.propolingo.propolinfo.model;

import com.propolingo.propolinfo.repository.PropolingoDatabase;
import com.propolingo.propolinfo.security.SecurityContext;
import com.propolingo.propolinfo.views.ViewFactory;

public class Models {

    private static Models model;
    private final ViewFactory viewFactory;
    private final PropolingoDatabase propolingoDatabaseConnection;
    private final SecurityContext securityContext ;

    public SecurityContext getSecurityContext(){
        return securityContext;
    }

    public Models()
    {
        viewFactory =new ViewFactory();
        propolingoDatabaseConnection =new PropolingoDatabase();
        securityContext = new SecurityContext();
    }

    public synchronized static Models getInstance()
    {
        if (model==null)
            model=new Models();
        return model;
    }

   public ViewFactory getViewFactory(){
        return viewFactory;
   }

   public PropolingoDatabase getPropolingoDatabase(){
        return propolingoDatabaseConnection;
   }
}
