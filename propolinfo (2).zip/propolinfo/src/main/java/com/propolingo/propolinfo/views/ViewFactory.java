package com.propolingo.propolinfo.views;

import com.propolingo.propolinfo.model.Models;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;

public class ViewFactory {
    private BorderPane app;
    private AnchorPane lessonsboard;
    private final String resources = "/fxml/";
    private AnchorPane login;
    private double xOffset = 0;
    private double yOffset = 0;
    Stage loginStage;

    private URL getResourceUrl(String resourcePath) {
        return getClass().getResource(resourcePath);
    }

    private Pane load(String resourcePath) throws IOException {
        return FXMLLoader.load(getResourceUrl(resourcePath));
    }

    public BorderPane getApp() throws IOException {
        if (app == null)
            app = (BorderPane) load(resources + "app.fxml");
        return app;
    }

    public void playMediaPlayer() throws IOException {
        AnchorPane anchorPane = (AnchorPane) load(resources + "media_player.fxml");
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }

    public void getNotes() throws IOException {
        AnchorPane notesPane = (AnchorPane) load(resources + "notes.fxml");
        Image icon = new Image(getResourceUrl("/images/notes_icon.png").toString());
        Scene scene = new Scene(notesPane);
        Stage stage = new Stage();
        stage.getIcons().add(icon);
        stage.setResizable(false);
        stage.setAlwaysOnTop(true);
        stage.setScene(scene);
        stage.show();
    }

    public Stage getLogin() {
        if (loginStage == null) {
            loginStage = new Stage();
            try {
                AnchorPane login = (AnchorPane) load(resources + "login.fxml");
                Scene scene = new Scene(login);
                scene.setFill(Color.TRANSPARENT);
                loginStage.initStyle(StageStyle.TRANSPARENT);
                login.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });

                login.setOnMouseDragged(event -> {
                    loginStage.setX(event.getScreenX() - xOffset);
                    loginStage.setY(event.getScreenY() - yOffset);
                });
                loginStage.setResizable(false);
                loginStage.setScene(scene);
                Image icon = new Image(getResourceUrl("/images/icon.jpg").toString());
                if (icon != null) loginStage.getIcons().add(icon);
                loginStage.show();
            } catch (IOException e) {
                e.printStackTrace(); // Consider adding some logging or error handling here
            }
        }
        return loginStage;
    }

    public void getLessons() throws IOException {
        setCenter();
        if (lessonsboard == null)
            lessonsboard = (AnchorPane) load(resources + "lessonsboard.fxml");
        lessonsboard.setVisible(true);

        BorderPane app = Models.getInstance().getViewFactory().getApp();
        Scene currentScene = app.getScene();
        double rightOffset = 10.0;
        double initialXPosition = app.getWidth() - lessonsboard.getWidth() - rightOffset;

        lessonsboard.setTranslateX(initialXPosition);

        StackPane newRoot = new StackPane(app, lessonsboard);
        currentScene.setRoot(newRoot);

        TranslateTransition slideIn = new TranslateTransition(Duration.millis(500), lessonsboard);
        slideIn.setFromX(initialXPosition);
        slideIn.setToX(rightOffset + 510);
        slideIn.play();
    }

    public void getCalculator() throws IOException {
        // Just Testing
        AnchorPane calc = (AnchorPane) load(resources + "calculator.fxml");
        Stage stage = new Stage();
        Scene scene = new Scene(calc);
        stage.setScene(scene);
        stage.setResizable(false);
        Image icon = new Image(getResourceUrl("/images/abacus.png").toString());
        stage.getIcons().add(icon);
        stage.setAlwaysOnTop(true);
        stage.show();
    }

    public void setCenter() throws IOException {
        AnchorPane symbolsLesson = (AnchorPane) load(resources + "symbolsnotes.fxml");

        if (getApp().getCenter() != null) {
            FadeTransition fadeOut = new FadeTransition(Duration.millis(500), getApp().getCenter());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);
            fadeOut.setOnFinished(event -> {
                try {
                    getApp().setCenter(symbolsLesson);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                FadeTransition fadeIn = new FadeTransition(Duration.millis(500), symbolsLesson);
                fadeIn.setFromValue(0.0);
                fadeIn.setToValue(1.0);
                fadeIn.play();
            });
            fadeOut.play();
        } else {
            getApp().setCenter(symbolsLesson);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), symbolsLesson);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        }
    }
}
