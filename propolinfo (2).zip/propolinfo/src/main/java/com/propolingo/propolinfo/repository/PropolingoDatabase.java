package com.propolingo.propolinfo.repository;

import java.sql.*;

public class PropolingoDatabase {
    private static final String DATABASE_URL = "jdbc:sqlite:src/main/database/propolingo.db";
    private  Connection connection;

    public PropolingoDatabase() {
        try {

            connection = DriverManager.getConnection(DATABASE_URL);
            System.out.println("Database connection established.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");

        }
    }

    public Connection getConnection() {
        return connection;
    }


    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to close the database connection.");
            e.printStackTrace();
        }
    }

    public boolean saveNote(int note_id){

        return false;
    }

    public boolean deleteNote(int note_id){
        return false;
    }

    public Note fetchNoteByLesson(Lesson lesson) {
        String noteQuery = "select * from NOTES where Notes.user_id=? and Notes.lesson_id=?";
        Note note = null;
        Connection connect = getConnection();

        try (PreparedStatement preparedStatement = connect.prepareStatement(noteQuery)) {
            preparedStatement.setInt(1, lesson.getUser_id());
            preparedStatement.setInt(2, lesson.getLesson_id());
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                note = new Note();
                note.setContent(resultSet.getString("content"));
                note.setNote_id(resultSet.getInt("note_id"));
                note.setLesson_id(resultSet.getInt("lesson_id"));
                note.setUser_id(resultSet.getInt("user_id"));
            }

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return note;
    }


    public User fetchByUsername(String username) {
        String userQuery = "SELECT * FROM USERS WHERE USERS.user_name = ?";
        User user = null;
        Connection connect = getConnection();
        try (
             PreparedStatement preparedStatement = connect.prepareStatement(userQuery)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setUsername(resultSet.getString("user_name"));
                user.setSurname(resultSet.getString("surname"));
                user.setId(resultSet.getInt("user_id"));
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }
    // Returns false if the user if user is not saved
    public boolean saveUser(User user) {
        Connection connect = getConnection();
        String userQuery = "INSERT INTO USERS(name, surname, password, email, user_name) VALUES(?, ?, ?, ?, ?)";
        try (
             PreparedStatement preparedStatement = connect.prepareStatement(userQuery)) {

            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getSurname());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setString(5, user.getUsername());

            int rowsAffected = preparedStatement.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("The username has already been taken");
        }
        return false;
    }


}
