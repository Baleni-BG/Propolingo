package com.propolingo.propolinfo.model;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.scene.control.Button;
import javafx.scene.control.Slider;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;

public class MediaPlayerModel {

    private Media media;
    private MediaPlayer mediaPlayer;
    public MediaView mediaView;
    private boolean clicked; // internal state variable of a button
    private String url;
    private final FontAwesomeIconView icon = new FontAwesomeIconView();
    public Slider slider;


    public MediaPlayerModel(MediaView mediaView) {
        this.mediaView = mediaView;
        this.clicked = false;
    }

    // Setters and Getters
    public void setUrl(String url) {
        this.url = url;
    }

    private String getUrl() {
        return url;
    }

    public void setSlider(Slider slider) {
        this.slider = slider;
        initializeSlider();
    }

    private Slider getSlider() {
        return slider;
    }

    // Private methods
    private void initializeSlider() {
        if (slider != null) {
            slider.setMin(0);
            slider.setMax(100);
            slider.setValue(0);
            slider.setShowTickLabels(true);
            slider.setShowTickMarks(true);
            slider.setBlockIncrement(5);
        }
    }

    private Media getMedia() {
        if (media == null) {
            media = new Media(getUrl());
        }
        return media;
    }

    private MediaPlayer getMediaPlayer() {
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer(getMedia());
            bindMediaPlayerSlider();
        }
        return mediaPlayer;
    }

    // Public methods
    public void onClickPlay(Button button) {
        if (!clicked) {
            clicked = true;
            icon.setGlyphName("PLAY");
            button.setGraphic(icon);
            getMediaPlayer().pause();
        } else {
            clicked = false;
            icon.setGlyphName("PAUSE");
            button.setGraphic(icon);
            getMediaPlayer().play();
        }
    }

    protected void bindMediaPlayerSlider() {
        if (slider != null && mediaPlayer != null) {
            mediaPlayer.currentTimeProperty().addListener((observable, oldValue, newValue) -> {
                slider.setValue(newValue.toSeconds() / mediaPlayer.getTotalDuration().toSeconds() * 100);
            });

            slider.valueProperty().addListener((observable, oldValue, newValue) -> {
                if (slider.isValueChanging()) {
                    mediaPlayer.seek(mediaPlayer.getTotalDuration().multiply(slider.getValue() / 100.0));
                }
            });
        }
    }

    public void initialize() {
        getMediaPlayer().play();
        getMediaPlayer().setVolume(1.0);
        mediaView.setMediaPlayer(getMediaPlayer());
    }
}
