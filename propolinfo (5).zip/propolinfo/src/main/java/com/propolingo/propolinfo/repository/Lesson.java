package com.propolingo.propolinfo.repository;

public class Lesson {

    private int lesson_id;
    private int user_id;
    private float cumulative_marks;
    private String lesson_name;

    public String getLesson_name() {
        return lesson_name;
    }

    public void setLesson_name(String lesson_name) {
        this.lesson_name = lesson_name;
    }

    public float getCumulative_marks() {
        return cumulative_marks;
    }

    public void setCumulative_marks(float cumulative_marks) {
        this.cumulative_marks = cumulative_marks;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getLesson_id() {
        return lesson_id;
    }

    public void setLesson_id(int lesson_id) {
        this.lesson_id = lesson_id;
    }



}
