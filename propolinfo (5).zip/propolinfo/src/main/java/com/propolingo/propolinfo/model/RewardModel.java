package com.propolingo.propolinfo.model;

import javafx.animation.PauseTransition;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.util.Duration;

public class RewardModel {
    private double score = 0;

    private Label medal_name, scored;
    private ImageView imageView;

    public RewardModel(Label medal_name, Label scored, ImageView imageView, double score) {
        this.score = score;
        this.scored = scored;
        this.medal_name = medal_name;
        this.imageView = imageView;
    }

    public void setMedal() {
        if (score < 50) {
            // Bronze
            medal_name.setText("Bronze Medal");
            scored.setText("Score: " + score);
            imageView.setImage(new Image(getClass().getResourceAsStream("/images/bronze_medal.png")));

            // Play the sound for Bronze Medal
            playBronzeMedalSound();
        } else if (score >= 50 && score <= 79) {
            // Silver
            medal_name.setText("Silver Medal");
            scored.setText("Score: " + score);
            imageView.setImage(new Image(getClass().getResourceAsStream("/images/silver_medal.png")));

            // Play the sound for Silver Medal
            playSilverMedalSound();
        } else {
            // Gold
            medal_name.setText("Gold Medal");
            scored.setText("Score: " + score);
            imageView.setImage(new Image(getClass().getResourceAsStream("/images/gold_medal.png")));

            // Play the sound for Gold Medal
            playGoldMedalSound();
        }
    }

    private void playBronzeMedalSound() {

        String soundPath = getClass().getResource("/Sounds/fail-jingle-stereo-mix-88784.mp3").toExternalForm();
        Media media = new Media(soundPath);
        MediaPlayer mediaPlayer = new MediaPlayer(media);

        mediaPlayer.play();

        PauseTransition pause = new PauseTransition(Duration.seconds(10));
        pause.setOnFinished(event -> mediaPlayer.stop());
        pause.play();
    }

    private void playSilverMedalSound() {
        String soundPath = getClass().getResource("/Sounds/game-bonus-144751.mp3").toExternalForm();
        Media media = new Media(soundPath);
        MediaPlayer mediaPlayer = new MediaPlayer(media);


        mediaPlayer.play();


        PauseTransition pause = new PauseTransition(Duration.seconds(10));
        pause.setOnFinished(event -> mediaPlayer.stop());
        pause.play();
    }

    private void playGoldMedalSound() {

        String soundPath = getClass().getResource("/Sounds/cheering-and-clapping-crowd-1-5995.mp3").toExternalForm();
        Media media = new Media(soundPath);
        MediaPlayer mediaPlayer = new MediaPlayer(media);


        mediaPlayer.play();


        PauseTransition pause = new PauseTransition(Duration.seconds(10));
        pause.setOnFinished(event -> mediaPlayer.stop());
        pause.play();
    }
}
