package com.propolingo.propolinfo.repository;

import java.io.File;

public class Video {

    public File getVideo() {
        return video;
    }

    public void setVideo(File video) {
        this.video = video;
    }

    private File video;




}
