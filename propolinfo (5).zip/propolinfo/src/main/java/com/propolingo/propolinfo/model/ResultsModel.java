package com.propolingo.propolinfo.model;

public class ResultsModel {

    private String studentName;
    private String schoolName ="Propolingo";
    private String slogan ="Understanding Prositional Logic";

    public void set(String topic , double grade ){
        /*
            Results table should like this
            | topic | grade | if grade >= 75 A symbol , if grade <75 but > =70 B , grade<70  and grade =>60 C , grade >= 50 <60 B , grade < 50 D
        *
        *
        * */

    }

}
