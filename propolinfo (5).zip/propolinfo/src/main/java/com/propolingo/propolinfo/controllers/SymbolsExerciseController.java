package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class SymbolsExerciseController implements Initializable {

        @FXML
        public TextField ans1;

        @FXML
        public TextField ans2;

        @FXML
        public TextField ans3;

        @FXML
        public TextField ans4;

        @FXML
        public TextField ans5;

        @FXML
        public TextField ans6;

        @FXML
        public TextField ans7;

        @FXML
        public TextField ans8;

        @FXML
        public TextField ans9;

        @FXML
        public Button nextButton;

        @FXML
        public Button prevButton;

        @FXML
        public ProgressBar progressBar;

        @FXML
        public Button submitButton;

        private Timeline timeline;

        @Override
        public void initialize(URL location, ResourceBundle resources) {
                startProgressBar(60);

                // Configure submit button action
                submitButton.setOnAction(event -> validate());
        }

        public void startProgressBar(int totalTimeInSeconds) {
                progressBar.setProgress(1.0); // Start with a full progress bar

                timeline = new Timeline(
                        new KeyFrame(Duration.seconds(1), event -> {
                                double progress = progressBar.getProgress() - (1.0 / totalTimeInSeconds);
                                progressBar.setProgress(progress);

                                if (progress <= (1.0 / 3.0)) {
                                        progressBar.lookup(".bar").setStyle("-fx-accent: red;");
                                }

                                // Stop the timeline and validate when the time is up
                                if (progress <= 0) {
                                        stopProgressBar();
                                        validate();
                                }
                        })
                );

                timeline.setCycleCount(totalTimeInSeconds);
                timeline.play();
        }

        public void stopProgressBar() {
                if (timeline != null) {
                        timeline.stop();
                }
        }

        private void validate() {
                // Expected answers
                String[] expectedAnswers = {"t", "t", "f", "t", "t", "t", "t", "f", "t"};
                TextField[] textFields = {ans1, ans2, ans3, ans4, ans5, ans6, ans7, ans8, ans9};
                int score = 0;

                // Validate answers
                for (int i = 0; i < textFields.length; i++) {
                        TextField textField = textFields[i];
                        String input = textField.getText().trim().toLowerCase();
                        if (input.equals(expectedAnswers[i])) {
                                textField.setBackground(new Background(new BackgroundFill(Color.LIGHTGREEN, null, null)));
                                score++;
                        } else {
                                textField.setBackground(new Background(new BackgroundFill(Color.LIGHTCORAL, null, null)));
                        }
                }

                AnchorPane anchorPane = Models.getInstance().getViewFactory().getReward(((score /(double) expectedAnswers.length) * 100));
                Scene scene = new Scene(anchorPane);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.show();
        }
}