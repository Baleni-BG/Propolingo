package com.propolingo.propolinfo.controllers;

import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class CellController {

    @FXML
    public Text avatar_text;


    public void setAvatar(String s){
        avatar_text.setText(s);
    }
    @FXML
    public Text position_text;

    public void setPosition(int num){
        position_text.setText(String.valueOf(num));
    }

}
