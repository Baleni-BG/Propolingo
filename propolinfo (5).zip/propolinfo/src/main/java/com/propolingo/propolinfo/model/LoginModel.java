package com.propolingo.propolinfo.model;

import com.propolingo.propolinfo.repository.User;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

public class LoginModel {

    public AnchorPane details;

    public AnchorPane details2;

    public ImageView imageview;

    public void setUsername(TextField username) {
        this.username = username;
    }

    public void setSignIn_button(Button signin_button) {
        this.signin_button = signin_button;
    }

    public void setSign_up_username_field(TextField sign_up_username_field) {
        this.sign_up_username_field = sign_up_username_field;
    }

    public void setSign_up_surname_field(TextField sign_up_surname_field) {
        this.sign_up_surname_field = sign_up_surname_field;
    }

    public void setSign_up_password_field(PasswordField sign_up_password_field) {
        this.sign_up_password_field = sign_up_password_field;
    }

    public void setSign_up_name_field(TextField sign_up_name_field) {
        this.sign_up_name_field = sign_up_name_field;
    }

    public void setSign_up_form(AnchorPane sign_up_form) {
        this.sign_up_form = sign_up_form;
    }

    public void setSign_up_email_field(TextField sign_up_email_field) {
        this.sign_up_email_field = sign_up_email_field;
    }

    public void setSign_up_button_layer2(Button sign_up_button_layer2) {
        this.sign_up_button_layer2 = sign_up_button_layer2;
    }

    public void setSign_in_layer2(Button sign_in_layer2) {
        this.sign_in_layer2 = sign_in_layer2;
    }

    public void setPassword(PasswordField password) {
        this.password = password;
    }

    public void setLayer_11(AnchorPane layer_11) {
        this.layer_2 = layer_11;
    }

    public void setLayer_1(AnchorPane layer_1) {
        this.layer_1 = layer_1;
    }

    public void setInvalid_log_in_details_anchorpane(AnchorPane invalid_log_in_details_anchorpane) {
        this.invalid_log_in_details_anchorpane = invalid_log_in_details_anchorpane;
    }

    public void setImageview(ImageView imageview) {
        this.imageview = imageview;
    }

    public void setDetails2(AnchorPane details2) {
        this.details2 = details2;
    }

    public void setDetails(AnchorPane details) {
        this.details = details;
    }

    public AnchorPane invalid_log_in_details_anchorpane;

    public AnchorPane layer_1;

    public AnchorPane layer_2;

    public PasswordField password;

    public Button sign_in_layer2;

    public Button sign_up_button_layer2;

    public TextField sign_up_email_field;

    public AnchorPane sign_up_form;

    public TextField sign_up_name_field;

    public PasswordField sign_up_password_field;

    public TextField sign_up_surname_field;

    public TextField sign_up_username_field;

    public Button signin_button;

    public TextField username;

    public LoginModel(){

    }
    public void blockDefaultClose( Stage primaryStage){
        primaryStage.addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, event -> {
            event.consume(); // Prevents the stage from closing
            System.out.println("Close button pressed, but action is blocked.");
        });
    }
    public void getApp() throws Exception{

        if (signIn()){
        BorderPane app=Models.getInstance().getViewFactory().getApp();
        Stage stage =new Stage();
        Scene scene =new Scene(app);
        stage.setScene(scene);
        stage.setTitle("Propolingo");
        Image icon = new Image(getClass().getResourceAsStream("/images/icon.jpg"));
        stage.getIcons().add(icon);
        stage.setResizable(false);
        blockDefaultClose(stage);
            // Close Login Stage
        Models.getInstance().getViewFactory().getLogin().close();
        stage.show();
        }

    }

    public boolean signIn(){
        String passwordField = password.getText();
        String usernameField =username.getText();
        Models.getInstance().getSecurityContext().setLoginDetails(usernameField, passwordField);
        return Models.getInstance().getSecurityContext().getSecurityContextUser() !=null; //user is registered?
    }


    public boolean signUp(){

        User user = new User();

        if (
                sign_up_surname_field.getText()==null || sign_up_surname_field.getText().isEmpty()||
                sign_up_password_field.getText()==null || sign_up_password_field.getText().isEmpty()||
                sign_up_username_field.getText()==null || sign_up_username_field.getText().isEmpty()||
                sign_up_email_field.getText() ==null || sign_up_email_field.getText().isEmpty()||
                sign_up_name_field.getText()==null   || sign_up_name_field.getText().isEmpty()
        )
            return false;

        user.setName(sign_up_name_field.getText().trim());
        user.setSurname(sign_up_surname_field.getText().trim());
        user.setPassword(sign_up_password_field.getText().trim());
        user.setEmail(sign_up_email_field.getText().trim());
        user.setUsername(sign_up_username_field.getText().trim());
        // Default
        sign_up_username_field.setText("");
        sign_up_password_field.setText("");
        sign_up_name_field.setText("");
        sign_up_email_field.setText("");
        sign_up_surname_field.setText("");

       return Models.getInstance().getPropolingoDatabase().saveUser(user); // Returns true if User is saved

    }

    public void animateSignUp() {

        sign_up_form.setVisible(true);
        sign_up_form.setOpacity(1);
        layer_2.setVisible(true);
        TranslateTransition translateTransition = new TranslateTransition(Duration.seconds(0.2), details2);
        TranslateTransition translateForm = new TranslateTransition(Duration.seconds(0.2), sign_up_form);
        translateForm.setToX(1);

        translateTransition.setToX(-1);
        translateTransition.play();
        translateForm.play();
    }


    public void animateSignIn(){

        TranslateTransition translateTransition =new TranslateTransition(Duration.seconds(0.2),details2 );
        TranslateTransition translateForm = new TranslateTransition(Duration.seconds(0.2),sign_up_form);
        translateForm.setToX(-527.19);

        translateForm.setOnFinished(e->{

            FadeTransition fadeTransition = new FadeTransition(Duration.seconds(0.5), sign_up_form);
            fadeTransition.setFromValue(1);
            fadeTransition.setToValue(0);

            fadeTransition.setOnFinished(fade-> sign_up_form.setVisible(false));
            fadeTransition.play();
        });

        translateTransition.setToX(621.19);

        translateTransition.setOnFinished(e->{
            layer_2.setVisible(false);

        });

        translateTransition.play();
        translateForm.play();

    }



}
