package com.propolingo.propolinfo.controllers;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.util.Duration;

public class EntailmentExerciseController {

    @FXML
    public TextField ans1;

    @FXML
    public TextField ans2;

    @FXML
    public TextField ans3;

    @FXML
    public TextField ans4;

    @FXML
    public TextField ans5;

    @FXML
    public TextField ans6;

    @FXML
    public TextField ans7;

    @FXML
    public Button nextButton;

    @FXML
    public Button prevButton;

    @FXML
    public ProgressBar progressBar;

    @FXML
    public Button submitButton;

    private Timeline timeline;
    private static final int TOTAL_TIME_IN_SECONDS = 240;

    @FXML
    private void initialize() {

        startProgressBar(TOTAL_TIME_IN_SECONDS);


    }

    private void startProgressBar(int totalTimeInSeconds) {
        progressBar.setProgress(1.0);

        timeline = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> {
                    double progress = progressBar.getProgress() - (1.0 / totalTimeInSeconds);
                    progressBar.setProgress(progress);

                    if (progress <= (1.0 / 3.0)) {
                        progressBar.lookup(".bar").setStyle("-fx-accent: red;");
                    }

                    if (progress <= 0) {
                        stopProgressBar();
                    }
                })
        );


        timeline.setCycleCount(totalTimeInSeconds);
        timeline.play();
    }

    private void stopProgressBar() {
        if (timeline != null) {
            timeline.stop();
        }
    }
}
