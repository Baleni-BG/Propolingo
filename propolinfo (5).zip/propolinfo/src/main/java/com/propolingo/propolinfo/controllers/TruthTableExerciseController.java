package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.DefaultStringConverter;

import java.net.URL;
import java.util.ResourceBundle;

public class TruthTableExerciseController implements Initializable {

    @FXML
    public Button nextButton;

    @FXML
    public Button prevButton;

    @FXML
    public ProgressBar progressBar;

    @FXML
    public Button submitButton;

    @FXML
    public TextArea textArea;

    @FXML
    public TableView<ObservableList<String>> truthTable;

    private Timeline timeline;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Set the table to be editable
        truthTable.setEditable(true);

        // Define columns for the truth table with propositional symbols
        String[] columnNames = {"p", "q", "r", "p ⇒ q", "¬r", "(p ⇒ q) ∧ ¬r"};
        for (String columnName : columnNames) {
            TableColumn<ObservableList<String>, String> column = new TableColumn<>(columnName);
            column.setPrefWidth(100); // Adjust width as needed

            // Define the cell value factory to retrieve data
            column.setCellValueFactory(param -> {
                int index = truthTable.getColumns().indexOf(column);
                if (index >= 0 && index < param.getValue().size()) {
                    return new javafx.beans.property.SimpleStringProperty(param.getValue().get(index));
                } else {
                    return new javafx.beans.property.SimpleStringProperty("");
                }
            });

            // Set cell factory to highlight empty cells
            column.setCellFactory(col -> new TextFieldTableCell<>(new DefaultStringConverter()) {
                @Override
                public void updateItem(String item, boolean empty) {
                    super.updateItem(item, empty);
                    if (item == null || item.isEmpty()) {
                        // Highlight empty cells with light blue (70% opacity)
                        setStyle("-fx-background-color: rgba(173, 216, 230, 0.7);");
                    } else {
                        // Reset style for non-empty cells
                        setStyle("");
                    }
                }
            });

            // Add column to the table
            truthTable.getColumns().add(column);
        }

        // Data rows matching the number of columns (6)
        ObservableList<ObservableList<String>> data = FXCollections.observableArrayList(
                FXCollections.observableArrayList("t", "", "", "t", "f", "f"),
                FXCollections.observableArrayList("t", "t", "f", "t", "t", "t"),
                FXCollections.observableArrayList("t", "f", "t", "f", "f", "f"),
                FXCollections.observableArrayList("f", "", "t", "t", "f", "f"),
                FXCollections.observableArrayList("t", "f", "f", "f", "", ""),
                FXCollections.observableArrayList("f", "f", "t", "t", "f", "f"),
                FXCollections.observableArrayList("", "f", "f", "t", "t", "t"),
                FXCollections.observableArrayList("f", "f", "t", "t", "f", "f")
        );

        // Set the data into the table
        truthTable.setItems(data);

        // Start the progress bar (example with 240 seconds)
        startProgressBar(240);

        // Configure submit button action
        submitButton.setOnAction(event -> validate());

        // Initialize the submit button state
        updateSubmitButtonState();
    }

    private void startProgressBar(int totalTimeInSeconds) {
        progressBar.setProgress(1.0); // Start with a full progress bar

        timeline = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> {
                    double progress = progressBar.getProgress() - (1.0 / totalTimeInSeconds);
                    progressBar.setProgress(progress);

                    // Change progress bar color when it reaches 1/3 or less
                    if (progress <= (1.0 / 3.0)) {
                        progressBar.lookup(".bar").setStyle("-fx-accent: red;");
                    }

                    // Stop progress bar when progress reaches zero
                    if (progress <= 0) {
                        stopProgressBar();
                    }
                })
        );

        // Run the timeline for the specified total time
        timeline.setCycleCount(totalTimeInSeconds);
        timeline.play();
    }

    private void stopProgressBar() {
        if (timeline != null) {
            timeline.stop();
        }
    }

    private void validate() {
        // Expected answers for each row in the truth table
        String[][] expectedAnswers = {
                {"t", "f", "f", "t", "f", "f"},
                {"t", "t", "f", "t", "f", "t"},
                {"t", "f", "t", "f", "f", "f"},
                {"f", "f", "t", "t", "t", "f"},
                {"t", "f", "f", "f", "t", "f"},
                {"f", "f", "t", "t", "f", "f"},
                {"f", "f", "f", "t", "t", "t"},
                {"f", "f", "t", "t", "f", "f"}
        };

        int score = 0;
        ObservableList<ObservableList<String>> items = truthTable.getItems();

        // Validate answers
        for (int row = 0; row < expectedAnswers.length; row++) {
            for (int col = 0; col < expectedAnswers[row].length; col++) {
                String input = items.get(row).get(col).trim().toLowerCase();
                if (input.equals(expectedAnswers[row][col])) {
                    score++;
                }
            }
        }

        // Create and show the reward anchor pane
        AnchorPane anchorPane = Models.getInstance().getViewFactory().getReward(((score / (double) expectedAnswers.length) * 100));
        Scene scene = new Scene(anchorPane);

        Stage stage = new Stage();
        stage.setScene(scene);
        stage.show();
    }

    private void updateSubmitButtonState() {
        boolean allFilled = truthTable.getItems().stream()
                .flatMap(row -> row.stream())
                .noneMatch(String::isEmpty);
        submitButton.setDisable(!allFilled);
    }
}
