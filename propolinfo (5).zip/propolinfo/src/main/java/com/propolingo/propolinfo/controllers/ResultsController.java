package com.propolingo.propolinfo.controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;

public class ResultsController {

    @FXML
    public Button download_button;

    @FXML
    public ImageView pdf_viewer;

}
