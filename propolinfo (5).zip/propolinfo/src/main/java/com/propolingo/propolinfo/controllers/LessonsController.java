package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

import java.net.URL;
import java.util.ResourceBundle;

public class LessonsController implements Initializable {

    @FXML
    public Button entailment_button;
    @FXML
    public Button equivalence_button;
    @FXML
    public Button exit_button;
    @FXML
    public ImageView imageview;
    @FXML
    public Button statements_button;
    @FXML
    public Button symbols_button;
    @FXML
    public Button truthtable_button;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Image icon = new Image(getClass().getResourceAsStream("/images/danger.png"));
        ImageView imageView = new ImageView(icon);
        imageView.setFitWidth(35);
        imageView.setFitHeight(35);
        exit_button.setGraphic(imageView);

        Tooltip exitHint =new Tooltip("Close");
        System.out.println("Delay :" + exitHint.getShowDelay());
        exitHint.setShowDelay(Duration.ZERO);
        Tooltip.install(exit_button,exitHint);
        exit_button.setOnMouseClicked(e->exit());
        Image student_icon = new Image(getClass().getResourceAsStream("/images/students.png"));
        imageview.setImage(student_icon);
        statements_button.setOnAction(e-> Models.getInstance().getViewFactory().setStatementNotes());
        truthtable_button.setOnAction(truthTable ->Models.getInstance().getViewFactory().setTruthTableNotes());
        equivalence_button.setOnAction(e->Models.getInstance().getViewFactory().setEquivalentNotes());
        entailment_button.setOnAction(e->Models.getInstance().getViewFactory().setEntailmentNotes());

    }

    public void exit(){
        Node parentNode = exit_button.getParent();

        if (parentNode instanceof AnchorPane) {
            AnchorPane anchorPane = (AnchorPane) parentNode;
            anchorPane.setVisible(false);

        } else {
            System.out.println("The parent node is not an AnchorPane.");
        }

    }
}
