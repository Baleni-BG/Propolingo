package com.propolingo.propolinfo.views;

import com.propolingo.propolinfo.controllers.CellController;
import com.propolingo.propolinfo.controllers.RewardController;
import com.propolingo.propolinfo.model.Models;
import javafx.animation.FadeTransition;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;

public class ViewFactory {
    private BorderPane app;
    private AnchorPane lessonsboard;
    private AnchorPane dashboard;
    private final String resources = "/fxml/";
    private AnchorPane login;
    private double xOffset = 0;
    private double yOffset = 0;
    Stage loginStage;
    private AnchorPane progress;
    AnchorPane reward;
    private Stage calculatorStage = null;
    private URL getResourceUrl(String resourcePath) {
        return getClass().getResource(resourcePath);
    }

    public Pane load(String resourcePath) throws IOException {
        return FXMLLoader.load(getResourceUrl(resourcePath));
    }

    public BorderPane getApp() throws IOException {
        if (app == null)
            app = (BorderPane) load(resources + "app.fxml");
        return app;
    }

    public void playMediaPlayer() throws IOException {
        AnchorPane anchorPane = (AnchorPane) load(resources + "media_player.fxml");
        Scene scene = new Scene(anchorPane);
        Stage stage = new Stage();
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }



    public AnchorPane getReward(double score ) {
        if (reward == null) {
            try {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/reward.fxml"));
                reward = loader.load();
                RewardController rewardController = loader.getController();

                rewardController.setScore(score);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return reward;
    }

    public void getNotes() throws IOException {
        AnchorPane notesPane = (AnchorPane) load(resources + "notes.fxml");
        Image icon = new Image(getResourceUrl("/images/notes_icon.png").toString());
        Scene scene = new Scene(notesPane);
        Stage stage = new Stage();
        stage.getIcons().add(icon);
        stage.setResizable(false);
        stage.setAlwaysOnTop(true);
        stage.setScene(scene);
        stage.show();
    }

    public Stage getLogin() {
        if (loginStage == null) {
            loginStage = new Stage();
            try {
                AnchorPane login = (AnchorPane) load(resources + "login.fxml");
                Scene scene = new Scene(login);
                scene.setFill(Color.TRANSPARENT);
                loginStage.initStyle(StageStyle.TRANSPARENT);
                login.setOnMousePressed(event -> {
                    xOffset = event.getSceneX();
                    yOffset = event.getSceneY();
                });

                login.setOnMouseDragged(event -> {
                    loginStage.setX(event.getScreenX() - xOffset);
                    loginStage.setY(event.getScreenY() - yOffset);
                });
                loginStage.setResizable(false);
                loginStage.setScene(scene);
                Image icon = new Image(getResourceUrl("/images/icon.jpg").toString());
                if (icon != null) loginStage.getIcons().add(icon);
                loginStage.show();
            } catch (IOException e) {
                e.printStackTrace(); 
            }
        }
        return loginStage;
    }

    public void getLessons() throws IOException {
        setCenter();
        if (lessonsboard == null)
            lessonsboard = (AnchorPane) load(resources + "lessonsboard.fxml");
        lessonsboard.setVisible(true);

        BorderPane app = Models.getInstance().getViewFactory().getApp();
        Scene currentScene = app.getScene();
        double rightOffset = 10.0;
        double initialXPosition = app.getWidth() - lessonsboard.getWidth() - rightOffset;

        lessonsboard.setTranslateX(initialXPosition);

        StackPane newRoot = new StackPane(app, lessonsboard);
        currentScene.setRoot(newRoot);

        TranslateTransition slideIn = new TranslateTransition(Duration.millis(500), lessonsboard);
        slideIn.setFromX(initialXPosition);
        slideIn.setToX(rightOffset + 510);
        slideIn.play();
    }

    public void getProgress() {
        if (progress == null) {
            try {
                progress = (AnchorPane) load(resources + "progress.fxml");
            } catch (IOException e) {
                System.err.println("Progress file not found.");
            }
        }
        try {
            setCenterExcercise(progress);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    public void getCalculator() throws IOException {

        if (calculatorStage == null) {

            AnchorPane calc = (AnchorPane) load(resources + "calculator.fxml");
            calculatorStage = new Stage();
            Scene scene = new Scene(calc);
            calculatorStage.setScene(scene);
            calculatorStage.setResizable(false);


            Image icon = new Image(getResourceUrl("/images/abacus.png").toString());
            calculatorStage.getIcons().add(icon);
            calculatorStage.setAlwaysOnTop(true);
        }
        calculatorStage.show();
    }

    public void setCenter() throws IOException {
        AnchorPane symbolsLesson = (AnchorPane) load(resources + "symbolsnotes.fxml");

        if (getApp().getCenter() != null) {
            FadeTransition fadeOut = new FadeTransition(Duration.millis(500), getApp().getCenter());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);
            fadeOut.setOnFinished(event -> {
                try {
                    getApp().setCenter(symbolsLesson);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                FadeTransition fadeIn = new FadeTransition(Duration.millis(500), symbolsLesson);
                fadeIn.setFromValue(0.0);
                fadeIn.setToValue(1.0);
                fadeIn.play();
            });
            fadeOut.play();
        } else {
            getApp().setCenter(symbolsLesson);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), symbolsLesson);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        }
    }

    private AnchorPane getDashboard(){
        if (dashboard==null) {
            try {
                dashboard =(AnchorPane) load(resources+ "dashboard.fxml");
            } catch (IOException e) {
                System.err.println("Dashboard file not found.");
            }
        }
        return dashboard;
    }
    public void setDashboard(){
        AnchorPane anchorPane =getDashboard();

        if (anchorPane!=null) {
            try {
                setCenterExcercise(anchorPane);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
    public void setStatementNotes(){
        try {
            AnchorPane anchorPane =(AnchorPane) load(resources+"statementNotes.fxml"); // wasting resources

            if (anchorPane!=null){
                setCenterExcercise(anchorPane);
            }

        } catch (IOException e) {
            System.err.println("Statement notes not found");
        }

    }

    public void setEntailmentNotes(){
        try {
            AnchorPane anchorPane =(AnchorPane) load(resources+"entailmentNotes.fxml"); // wasting resources

            if (anchorPane!=null){
                setCenterExcercise(anchorPane);
            }

        } catch (IOException e) {
            System.err.println("Statement notes not found");
        }
    }

    public void setEntailmentExercise(){
        try {
            AnchorPane anchorPane =(AnchorPane) load(resources+"entailment.fxml"); // wasting resources

            if (anchorPane!=null){
                setCenterExcercise(anchorPane);
            }

        } catch (IOException e) {
            System.err.println("Statement notes not found");
        }
    }

    public void setEquivalentNotes(){
        try {
            AnchorPane anchorPane = (AnchorPane) load(resources+"equivalenceNotes.fxml");
            if (anchorPane!=null)
                setCenterExcercise(anchorPane);
        }catch (IOException x){}
    }

    public void setEquivalenceExercise(){
        try {
            AnchorPane anchorPane = (AnchorPane) load(resources+"equivalenceExercise.fxml");
            if (anchorPane!=null)
                setCenterExcercise(anchorPane);
        }catch (IOException x){}
    }


    public AnchorPane getCell(String avatar, int num) {
        AnchorPane cell = null;
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/cell.fxml"));
            cell = loader.load();
            CellController controller = loader.getController();
            controller.setAvatar(avatar);
            controller.setPosition(num);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return cell;
    }


    public void setTruthTableNotes(){
        try {
            AnchorPane anchorPane = (AnchorPane) load(resources+"truthTableNotes.fxml");
            if (anchorPane!=null)
                setCenterExcercise(anchorPane);
        }catch (IOException x){}
    }

    public void setTruthTableExercise(){
        try {
            AnchorPane anchorPane = (AnchorPane) load(resources+"truthTableExercise.fxml");
            if (anchorPane!=null)
                setCenterExcercise(anchorPane);
        }catch (IOException x){}
    }

    public void setStatementExercise(){
        try {
            AnchorPane anchorPane = (AnchorPane) load(resources+"statementsExercise.fxml");
            if (anchorPane!=null)
                setCenterExcercise(anchorPane);
        }catch (IOException x){}

    }

    public void setCenterExcercise(AnchorPane newCenterPane) throws IOException {
        if (getApp().getCenter() != null) {
            FadeTransition fadeOut = new FadeTransition(Duration.millis(500), getApp().getCenter());
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);
            fadeOut.setOnFinished(event -> {
                try {
                    getApp().setCenter(newCenterPane);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                FadeTransition fadeIn = new FadeTransition(Duration.millis(500), newCenterPane);
                fadeIn.setFromValue(0.0);
                fadeIn.setToValue(1.0);
                fadeIn.play();
            });
            fadeOut.play();
        } else {
            getApp().setCenter(newCenterPane);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), newCenterPane);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);
            fadeIn.play();
        }
    }
}
