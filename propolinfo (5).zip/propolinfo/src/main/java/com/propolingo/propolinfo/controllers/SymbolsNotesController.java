package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SymbolsNotesController implements Initializable {

    @FXML
    public Button take_quiz_button;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        take_quiz_button.setOnAction(e-> {
            try {
                load();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
    }

    private void load() throws IOException {
        AnchorPane load = (AnchorPane) Models.getInstance().getViewFactory().load("/fxml/symbolsExercise.fxml");
        Models.getInstance().getViewFactory().setCenterExcercise(load);
    }
}
