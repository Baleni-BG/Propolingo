package com.propolingo.propolinfo.controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.net.URL;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    @FXML
    public BarChart<String, Number> barchart;
    @FXML
    public CategoryAxis xAxis;
    @FXML
    public NumberAxis yAxis;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        xAxis.setLabel("Lessons");
        yAxis.setLabel("Marks");
        yAxis.setAutoRanging(false);
        yAxis.setLowerBound(0);
        yAxis.setUpperBound(100);
        yAxis.setTickUnit(10);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Marks Summary");

        series.getData().add(new XYChart.Data<>("Symbols", 70));

        System.out.println("Added data: " + series.getData());
        series.getData().add(new XYChart.Data<>("Statements", 90));
        series.getData().add(new XYChart.Data<>("Truth Table", 75));
        series.getData().add(new XYChart.Data<>("Equivalence", 80));
        series.getData().add(new XYChart.Data<>("Entailment", 70));




        barchart.getData().add(series);
    }
}
