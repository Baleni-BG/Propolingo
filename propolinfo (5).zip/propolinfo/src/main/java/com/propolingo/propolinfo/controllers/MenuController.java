package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class MenuController implements Initializable {

    @FXML
    public Button lessons_button;
    @FXML
    public Button notes_button;
    @FXML
    public Button signout_button;

    @FXML
    public Button home_button;

    public Button progress_button;



    @FXML
    public  Button calculator_button;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        //Button hints

        hint(signout_button, "Exit App");
        hint(lessons_button, "Choose a Lesson");
        hint(notes_button,"Write Notes");
        hint(calculator_button,"Propositional Logic Calculator");
        hint(home_button,"Dashboard");
        hint(progress_button , "Leaderboard");
        progress_button.setOnAction(e->Models.getInstance().getViewFactory().getProgress());
        home_button.setOnAction(e->Models.getInstance().getViewFactory().setDashboard());

        calculator_button.setOnMouseClicked( e->{
                try{
                        Models.getInstance().getViewFactory().getCalculator();
                 }catch (Exception m){}
        }
        );


        signout_button.setOnMouseClicked(e-> signOut());

        lessons_button.setOnMouseClicked(e-> {
            try {
                Models.getInstance().getViewFactory().getLessons();
            } catch (IOException ignored) {

            }
        });
        notes_button.setOnMouseClicked(e->{
            try {
                Models.getInstance().getViewFactory().getNotes();
            }catch (IOException i){}
                }
        );




    }

    // Signout - Should close database connection , should close all stages of the app.
    private void signOut(){
        // Close database connection
        Models.getInstance().getPropolingoDatabase().closeConnection();


        System.exit(0);// Succesful Exit
        Platform.exit();

    }


    private void hint(Button button, String hint){
        if (button !=null && hint !=null) {
            Tooltip tooltip = new Tooltip(hint);
            tooltip.setShowDelay(Duration.ZERO);
            Tooltip.install(button,tooltip);
        }
    }


}
