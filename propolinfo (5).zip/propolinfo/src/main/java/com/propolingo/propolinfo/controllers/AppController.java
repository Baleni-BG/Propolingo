package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.text.Text;

import java.net.URL;
import java.util.ResourceBundle;

public class AppController  implements Initializable {

    @FXML
    public Text avatar;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
       if (Models.getInstance().getSecurityContext().getSecurityContextUser() !=null)
            avatar.setText(Models.getInstance().getSecurityContext().getSecurityContextUser().getUsername());

    }
}