package com.propolingo.propolinfo.controllers;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.beans.binding.Bindings;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.Button;
import javafx.util.Duration;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

public class StatementsExerciseController implements Initializable {

    @FXML
    public Text ans1_text;

    @FXML
    public Text ans2_text;

    @FXML
    public Text ans3_text;

    @FXML
    public TextField ans1;

    @FXML
    public TextField ans2;

    @FXML
    public TextField ans3;

    @FXML
    public Text formular_text;

    @FXML
    public Button nextButton;

    @FXML
    public Button prevButton;

    @FXML
    public ProgressBar progressBar;

    @FXML
    public Button submitButton;

    private final Map<String, String> symbolMap = new HashMap<>();
    private Timeline timeline;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        initializeSymbolMap();

        // Bind TextFields to their corresponding Texts
        bindTextFields();

        // Start the progress bar
        startProgressBar(180);
    }

    private void initializeSymbolMap() {
        symbolMap.put("->", "→");  // Implies
        symbolMap.put("&", "∧");   // And
        symbolMap.put("|", "∨");   // Or
        symbolMap.put("=", "↔");   // Equivalence
        symbolMap.put("!", "¬");   // Not
        symbolMap.put("%", "⊨");   // Entailment
    }

    private String replaceSymbols(String text) {
        for (Map.Entry<String, String> entry : symbolMap.entrySet()) {
            text = text.replace(entry.getKey(), entry.getValue());
        }
        return text;
    }

    private void bindTextFields() {
        // Bind ans1 TextField to ans1_text
        ans1_text.textProperty().bind(Bindings.createStringBinding(() -> replaceSymbols(ans1.getText()), ans1.textProperty()));

        // Bind ans2 TextField to ans2_text
        ans2_text.textProperty().bind(Bindings.createStringBinding(() -> replaceSymbols(ans2.getText()), ans2.textProperty()));

        // Bind ans3 TextField to ans3_text
        ans3_text.textProperty().bind(Bindings.createStringBinding(() -> replaceSymbols(ans3.getText()), ans3.textProperty()));
    }

    private void startProgressBar(int totalTimeInSeconds) {
        progressBar.setProgress(1.0); // Start with a full progress bar

        timeline = new Timeline(
                new KeyFrame(Duration.seconds(1), event -> {
                    double progress = progressBar.getProgress() - (1.0 / totalTimeInSeconds);
                    progressBar.setProgress(progress);

                    if (progress <= (1.0 / 3.0)) {
                        progressBar.lookup(".bar").setStyle("-fx-accent: red;");
                    }

                    if (progress <= 0) {
                        stopProgressBar();
                    }
                })
        );

        timeline.setCycleCount(totalTimeInSeconds);
        timeline.play();
    }

    private void stopProgressBar() {
        if (timeline != null) {
            timeline.stop();
        }
    }
}
