package com.propolingo.propolinfo;

public class Propolingo {
    public static void main(String[] args){
       Main.main(args);
    }
}
