package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.RewardModel;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;


public class RewardController  {
    RewardModel model;
    @FXML
    public ImageView medal_image;

    @FXML
    public Label medal_label;

    @FXML
    public Label score;

    public void setScore(double studentScore) {
        model = new RewardModel(medal_label, score, medal_image, studentScore);
        model.setMedal();
    }
}
