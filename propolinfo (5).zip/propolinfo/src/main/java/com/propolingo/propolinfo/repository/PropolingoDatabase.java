package com.propolingo.propolinfo.repository;

import java.sql.*;

public class PropolingoDatabase {
    private static final String DATABASE_URL = "jdbc:sqlite:src/main/resources/database/propolingo.db";
    private Connection connection;

    public PropolingoDatabase() {
        try {
            connection = DriverManager.getConnection(DATABASE_URL);
            System.out.println("Database connection established.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            e.printStackTrace();
        }
    }

    public Connection getConnection() {
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("Failed to close the database connection.");
            e.printStackTrace();
        }
    }

    public boolean saveNote(int note_id, String content, int lesson_id, int user_id) {
        String noteQuery;
        // Determine if we are inserting a new note or updating an existing one
        if (note_id <= 0) {
            noteQuery = "INSERT INTO NOTES(content, lesson_id, user_id) VALUES(?, ?, ?)";
        } else {
            noteQuery = "UPDATE NOTES SET content = ? WHERE note_id = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(noteQuery)) {
            preparedStatement.setString(1, content);

            // If it's an update, set the note_id
            if (note_id > 0) {
                preparedStatement.setInt(2, note_id);
            } else {
                // For new notes, set the lesson_id and user_id
                preparedStatement.setInt(2, lesson_id);
                preparedStatement.setInt(3, user_id);
            }

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was affected

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteNote(int note_id) {
        String deleteQuery = "DELETE FROM NOTES WHERE note_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setInt(1, note_id);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was deleted
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public Note fetchNoteByLesson(Lesson lesson) {
        String noteQuery = "SELECT * FROM NOTES WHERE user_id=? AND lesson_id=?";
        Note note = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(noteQuery)) {
            preparedStatement.setInt(1, lesson.getUser_id());
            preparedStatement.setInt(2, lesson.getLesson_id());
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                note = new Note();
                note.setContent(resultSet.getString("content"));
                note.setNote_id(resultSet.getInt("note_id"));
                note.setLesson_id(resultSet.getInt("lesson_id"));
                note.setUser_id(resultSet.getInt("user_id"));
            }

        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        }

        return note;
    }

    public User fetchByUsername(String username) {
        String userQuery = "SELECT * FROM USERS WHERE user_name = ?";
        User user = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(userQuery)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                user = new User();
                user.setUsername(resultSet.getString("user_name"));
                user.setSurname(resultSet.getString("surname"));
                user.setId(resultSet.getInt("user_id"));
                user.setEmail(resultSet.getString("email"));
                user.setPassword(resultSet.getString("password"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    public boolean saveUser(User user) {
        String userQuery = "INSERT INTO USERS(name, surname, password, email, user_name) VALUES(?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(userQuery)) {
            preparedStatement.setString(1, user.getName());
            preparedStatement.setString(2, user.getSurname());
            preparedStatement.setString(3, user.getPassword());
            preparedStatement.setString(4, user.getEmail());
            preparedStatement.setString(5, user.getUsername());

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("The username has already been taken");
            e.printStackTrace();
        }
        return false;
    }

    public boolean saveLesson(int lesson_id, String lesson_name, double cumulative_marks, int user_id) {
        String lessonQuery;
        // Determine if we are inserting a new lesson or updating an existing one
        if (lesson_id <= 0) {
            lessonQuery = "INSERT INTO LESSONS(lesson_name, cumulative_marks, user_id) VALUES(?, ?, ?)";
        } else {
            lessonQuery = "UPDATE LESSONS SET lesson_name = ?, cumulative_marks = ? WHERE lesson_id = ?";
        }

        try (PreparedStatement preparedStatement = connection.prepareStatement(lessonQuery)) {
            preparedStatement.setString(1, lesson_name);
            preparedStatement.setDouble(2, cumulative_marks);

            // If it's an update, set the lesson_id
            if (lesson_id > 0) {
                preparedStatement.setInt(3, lesson_id);
            } else {
                // For new lessons, set the user_id
                preparedStatement.setInt(3, user_id);
            }

            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean deleteLesson(int lesson_id) {
        String deleteQuery = "DELETE FROM LESSONS WHERE lesson_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
            preparedStatement.setInt(1, lesson_id);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; 
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
