package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import java.net.URL;
import java.util.ResourceBundle;

public class EquivalenceNotesController implements Initializable {

    @FXML
    public Button take_quiz_button;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        take_quiz_button.setOnAction(event-> Models.getInstance().getViewFactory().setEquivalenceExercise());
    }
}
