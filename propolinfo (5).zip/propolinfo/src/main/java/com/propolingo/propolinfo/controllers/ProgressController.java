package com.propolingo.propolinfo.controllers;

import com.propolingo.propolinfo.model.Models;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ResourceBundle;

public class ProgressController  implements Initializable {

    @FXML
    public ListView<AnchorPane> listView;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        int i=0;
        while (i < 10) {

            AnchorPane cell = Models.getInstance().getViewFactory().getCell("User "+i , i + 1);

            listView.getItems().add(cell);

            System.out.println( cell);

            i++;
    }
}

}
